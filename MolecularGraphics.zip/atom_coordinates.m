
x0 = 1.5*a0;
y0 = sqrt(3)/2*a0;
x (1:2:N) = 0;x (2:2:N) = x0;
x (N+1:2:2*N) = a0;x (N+2:2:2*N) = a0-x0;

y (1:N) = ((1:N)-1)*y0; y (N+1:2*N) = ((1:N)-1)*y0;

coord(:,1) = x;
coord(:,2) = y;
coord(:,3) = 0;
coord(2*N+1,:) = [x(N+2),y(1)-y0*0.9,0];
coord(2*N+2,:) = [x(2),y(N+1)-y0*0.9,0];
coord(2*N+3,:) = [x(N+2),y(N)+y0*0.9,0];
coord(2*N+4,:) = [x(2),y(2*N)+y0*0.9,0];

for ii = 1 : L
    count = (ii-1)*(2*N+4);
    coord(count+(1:2*N+4),1) = coord(1:2*N+4,1) + (ii-1)*3*a0;
    coord(count+(1:2*N+4),2) = coord(1:2*N+4,2);
    coord(count+(1:2*N+4),3) = coord(1:2*N+4,3);
    atom_types(count+(1:N),1) = atom_A;
    atom_types(count+(N+1:2*N),1) = atom_B;
    atom_types(count+(2*N+1:2*N+4),1) = 'H';
end;clear ii
clear c
for i = 1:size(atom_types,1)
    c{i,1} = atom_types(i,1);
    c{i,2} = coord(i,1);
    c{i,3} = coord(i,2);
    c{i,4} = coord(i,3);
end;

clear x x0 y y0 atom_types coord 




