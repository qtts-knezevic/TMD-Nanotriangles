clear;
clc;
F = 1.9;
TMD.a = 3.2e-10/sqrt(3)*1e10*F;
TMD.L = 3e-9*1e10*F;

x0 = TMD.L/2;
y0 = sqrt(3)/6*TMD.L;
% -------------------------------------------------------------------------
%   Generate the high-resolution XY grid
% -------------------------------------------------------------------------
[MeshTMD.Y,MeshTMD.X] = meshgrid(-y0:3*TMD.a/sqrt(3):2*y0,-x0:TMD.a:x0);

% -------------------------------------------------------------------------
%   Calculate the position of Mo and S atoms
% -------------------------------------------------------------------------

MeshTMD.X = [MeshTMD.X , (MeshTMD.X+TMD.a/2)];
MeshTMD.Y = [MeshTMD.Y , (MeshTMD.Y+3*TMD.a/sqrt(3)/2)];

MeshTMD.Nx = size(MeshTMD.X,1);
MeshTMD.Ny = size(MeshTMD.X,2);
Tri = zeros(MeshTMD.Nx,MeshTMD.Ny);
for iy = 1:MeshTMD.Ny
    for ix = 1:MeshTMD.Nx
        if (MeshTMD.Y(ix,iy)-sqrt(3)*MeshTMD.X(ix,iy))<2*y0 && (MeshTMD.Y(ix,iy)+sqrt(3)*MeshTMD.X(ix,iy))<2*y0
            Tri(ix,iy) = 1;
        end;
    end;
end;clear iy
Tri(1,1) = 0;
count = 1;
for ix = 1:MeshTMD.Nx
    for iy = 1:MeshTMD.Ny
        if Tri(ix,iy) == 1
            c{count,1} = 'Mo';
            c{count,2} = MeshTMD.X(ix,iy);
            c{count,3} = MeshTMD.Y(ix,iy);
            c{count,4} = 0;
            count = count+1;
        end;
    end;
end;

MeshTMD.Y = MeshTMD.Y-TMD.a/sqrt(3);
MeshTMD.Nx = size(MeshTMD.X,1);
MeshTMD.Ny = size(MeshTMD.X,2);
Tri = zeros(MeshTMD.Nx,MeshTMD.Ny);
for iy = 1:MeshTMD.Ny
    for ix = 1:MeshTMD.Nx
        if (MeshTMD.Y(ix,iy)-sqrt(3)*MeshTMD.X(ix,iy))<2*y0 && (MeshTMD.Y(ix,iy)+sqrt(3)*MeshTMD.X(ix,iy))<2*y0
            Tri(ix,iy) = 1;
        end;
    end;
end;clear iy
Tri(1,1) = 0;

for ix = 1:MeshTMD.Nx
    for iy = 1:MeshTMD.Ny
        if Tri(ix,iy) == 1
            c{count,1} = 'S';
            c{count,2} = MeshTMD.X(ix,iy);
            c{count,3} = MeshTMD.Y(ix,iy);
            c{count,4} = TMD.a/2;
            count = count+1;
            
            c{count,1} = 'S';
            c{count,2} = MeshTMD.X(ix,iy);
            c{count,3} = MeshTMD.Y(ix,iy);
            c{count,4} = -TMD.a/2;
            count = count+1;
        end;
    end;
end;
%%
fid = fopen('output.xyz','w');

fprintf(fid,'%d \n',size(c,1));
fprintf(fid,'\n');
for i = 1:size(c,1)
    fprintf(fid,'%s \t\t %1.5f \t\t %1.5f \t\t %1.5f\n',c{i,:});
    %         fprintf(fid,'%s, %1.5f, %1.5f, %1.5f\n',c{i,:});
end;
fclose(fid);

molviewer('output.xyz')




