LatticeCnst = 1e-10*[3.160 3.288 3.153 3.260];
EnergyParms = Q*[+0.086 +0.089 +0.271 +0.251;
         +0.052 +0.256 +0.057 +0.439;
         -1.094 -1.144 -1.155 -.9350;
         -0.050 -0.250 -0.650 -1.250;
         -1.511 -1.488 -2.279 -2.321;
         -3.559 -4.931 -3.864 -5.629;
         -6.886 -7.503 -7.327 -6.759;
         +3.689 +3.728 +4.911 +5.083;
         -1.241 -1.222 -1.220 -1.081;
         -0.895 -0.823 -1.328 -1.129;
         +0.252 +0.215 +0.121 +0.094;
         +0.228 +0.192 +0.442 +0.317;
         +1.225 +1.256 +1.178 +1.530;
         -0.467 -0.205 -0.273 -0.123];
     
TMD.a = LatticeCnst(iType);
TMD.d = TMD.a/sqrt(3);

Parm.a1 = TMD.a/2*[-1,sqrt(3)];
Parm.a2 = TMD.a*[1,0];
Parm.a3 = TMD.a/2*[-1,-sqrt(3)];

Parm.d1 = TMD.d/2*[sqrt(3),-1];
Parm.d2 = TMD.d*[0,1];
Parm.d3 = TMD.d/2*[-sqrt(3),-1];

Parm.lambdaM = EnergyParms(1,iType);
Parm.lambdaX = EnergyParms(2,iType);

Parm.Delta_0  = EnergyParms(3,iType);
Parm.Delta_1  = EnergyParms(4,iType);
Parm.Delta_2  = EnergyParms(5,iType);
Parm.Delta_p  = EnergyParms(6,iType);
Parm.Delta_z  = EnergyParms(7,iType);

Parm.Vpds    = EnergyParms(8,iType);
Parm.Vpdp    = EnergyParms(9,iType);
Parm.Vdds    = EnergyParms(10,iType);
Parm.Vddp    = EnergyParms(11,iType);
Parm.Vddd    = EnergyParms(12,iType);
Parm.Vpps    = EnergyParms(13,iType);
Parm.Vppp    = EnergyParms(14,iType);
