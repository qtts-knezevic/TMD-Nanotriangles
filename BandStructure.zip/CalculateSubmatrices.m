T.M = [Parm.Delta_0 0                0; 
       0       Parm.Delta_2          -1i*Parm.lambdaM*Spin; 
       0       1i*Parm.lambdaM*Spin Parm.Delta_2];
   
T.X = [Parm.Delta_p+Parm.Vppp      -1i/2*Parm.lambdaX*Spin 0;
       1i/2*Parm.lambdaX*Spin Parm.Delta_p+Parm.Vppp       0;
       0                  0                   Parm.Delta_z-Parm.Vpps];

%%
T.MM(:,:,1) = 1/4*[3*Parm.Vddd+Parm.Vdds            sqrt(3)/2*(-Parm.Vddd+Parm.Vdds)          -3/2*(Parm.Vddd-Parm.Vdds);
             sqrt(3)/2*(-Parm.Vddd+Parm.Vdds) 1/4*(Parm.Vddd+12*Parm.Vddp+3*Parm.Vdds)      sqrt(3)/4*(Parm.Vddd-4*Parm.Vddp+3*Parm.Vdds);
             -3/2*(Parm.Vddd-Parm.Vdds)       sqrt(3)/4*(Parm.Vddd-4*Parm.Vddp+3*Parm.Vdds) 1/4*(3*Parm.Vddd+4*Parm.Vddp+9*Parm.Vdds)];

T.MM(:,:,2) = 1/4*[3*Parm.Vddd+Parm.Vdds         sqrt(3)*(Parm.Vddd-Parm.Vdds) 0;
             sqrt(3)*(Parm.Vddd-Parm.Vdds) Parm.Vddd+3*Parm.Vdds         0;
             0                     0                     4*Parm.Vddp];
         
T.MM(:,:,3) = 1/4*[3*Parm.Vddd+Parm.Vdds            sqrt(3)/2*(-Parm.Vddd+Parm.Vdds)          3/2*(Parm.Vddd-Parm.Vdds);
             sqrt(3)/2*(-Parm.Vddd+Parm.Vdds) 1/4*(Parm.Vddd+12*Parm.Vddp+3*Parm.Vdds)      -sqrt(3)/4*(Parm.Vddd-4*Parm.Vddp+3*Parm.Vdds);
             3/2*(Parm.Vddd-Parm.Vdds)       -sqrt(3)/4*(Parm.Vddd-4*Parm.Vddp+3*Parm.Vdds) 1/4*(3*Parm.Vddd+4*Parm.Vddp+9*Parm.Vdds)];
%%         
T.XX(:,:,1) = 1/4*[3*Parm.Vppp+Parm.Vpps         sqrt(3)*(Parm.Vppp-Parm.Vpps) 0;
             sqrt(3)*(Parm.Vppp-Parm.Vpps) Parm.Vppp+3*Parm.Vpps         0;
             0                     0                     4*Parm.Vppp];

T.XX(:,:,2) = [Parm.Vpps 0     0;
         0     Parm.Vppp 0;
         0     0     Parm.Vppp];

T.XX(:,:,3) = 1/4*[3*Parm.Vppp+Parm.Vpps          -sqrt(3)*(Parm.Vppp-Parm.Vpps) 0;
             -sqrt(3)*(Parm.Vppp-Parm.Vpps) Parm.Vppp+3*Parm.Vpps          0;
             0                      0                      4*Parm.Vppp];
%% Rostami        
T.MX(:,:,1) = sqrt(2/7)/7*[-9*Parm.Vpdp+sqrt(3)*Parm.Vpds sqrt(27)*Parm.Vpdp-Parm.Vpds   12*Parm.Vpdp+sqrt(3)*Parm.Vpds;
                     sqrt(75)*Parm.Vpdp+3*Parm.Vpds 9*Parm.Vpdp-sqrt(3)*Parm.Vpds  -sqrt(12)*Parm.Vpdp+3*Parm.Vpds;
                     -Parm.Vpdp-sqrt(27)*Parm.Vpds  sqrt(75)*Parm.Vpdp+3*Parm.Vpds 6*Parm.Vpdp-sqrt(27)*Parm.Vpds];
                 
T.MX(:,:,2) = sqrt(2/7)/7*[0        -sqrt(108)*Parm.Vpdp+2*Parm.Vpds 12*Parm.Vpdp+sqrt(3)*Parm.Vpds;
                     0        -6*Parm.Vpdp-sqrt(48)*Parm.Vpds  sqrt(48)*Parm.Vpdp-6*Parm.Vpds;
                     14*Parm.Vpdp 0                        0];

T.MX(:,:,3) = sqrt(2/7)/7*[9*Parm.Vpdp-sqrt(3)*Parm.Vpds   sqrt(27)*Parm.Vpdp-Parm.Vpds    12*Parm.Vpdp+sqrt(3)*Parm.Vpds;
                     -sqrt(75)*Parm.Vpdp-3*Parm.Vpds 9*Parm.Vpdp-sqrt(3)*Parm.Vpds   -sqrt(12)*Parm.Vpdp+3*Parm.Vpds;
                     -Parm.Vpdp-sqrt(27)*Parm.Vpds   -sqrt(75)*Parm.Vpdp-3*Parm.Vpds -6*Parm.Vpdp+sqrt(27)*Parm.Vpds];
                 