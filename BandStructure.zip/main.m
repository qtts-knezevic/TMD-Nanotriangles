%% Electronic band structure of TMDs 
% J. �. Silva-Guill�n, P. San-Jose, and R. Rold�n, Appl. Sci. 6, 284 (2016).
% E. Cappelluti, R. Roldan, J. A. Silva-Guillen, P. Ordejon, and F. Guinea, Phys. Rev. B 88, 075409 (2013)
% H. Rostami, R. Roldan, E. Cappelluti, R. Asgari, and F. Guinea, Phys. Rev. B 92, 195402 (2015)

clear;
clc;

Q = 1.6e-19;
%% BZ band structure
% select the MX2:
%  1 MoS2
%  2 MoSe2
%  3 WS2
%  4 WSe2

iType = 1;
Spin = +1;


ImportParameters;
CalculateSubmatrices;

Mesh.Nk = 201;
Mesh.k = linspace(-1,1,Mesh.Nk)*4*pi/3/TMD.a;
Mesh.dk = Mesh.k(2)-Mesh.k(1);

for ix = 1:Mesh.Nk
    disp(ix)
    for iy = 1:Mesh.Nk
        K = [Mesh.k(ix), Mesh.k(iy)];
        H_MM = T.M + 2*T.MM(:,:,1)*cos(K*Parm.a1') + 2*T.MM(:,:,2)*cos(K*Parm.a2') + 2*T.MM(:,:,3)*cos(K*Parm.a3');
        H_XX = T.X + 2*T.XX(:,:,1)*cos(K*Parm.a1') + 2*T.XX(:,:,2)*cos(K*Parm.a2') + 2*T.XX(:,:,3)*cos(K*Parm.a3');
        H_MX = T.MX(:,:,1)*exp(-1i*K*Parm.d1') + T.MX(:,:,2)*exp(-1i*K*Parm.d2') + T.MX(:,:,3)*exp(-1i*K*Parm.d3');
        
        H = [H_MM  H_MX;
             H_MX' H_XX];
        TMD.E(ix,iy,:) = eig(H);
    end;
end;clear ix iy H_* K H
figure(11)
surf(Mesh.k,Mesh.k,TMD.E(:,:,5)/Q,'edgecolor','none');view([0 90]); axis tight; axis equal;
figure(22)
surf(Mesh.k,Mesh.k,TMD.E(:,:,4)/Q,'edgecolor','none');view([0 90]); axis tight; axis equal;

%% Carrier density calculation
TMD.Ec = min(min(TMD.E(:,:,5)))/Q;
TMD.Ev = max(max(TMD.E(:,:,4)))/Q;
TMD.Ef = TMD.Ec*Q - 0.022*Q;

TMD.n = 4*sum(sum(1./(1+exp((TMD.E(:,:,5)-TMD.Ef)/0.026/Q))))*Mesh.dk^2/4/pi^2/1e4;
TMD.p = 4*sum(sum(1-1./(1+exp((TMD.E(:,:,4)-TMD.Ef)/0.026/Q))))*Mesh.dk^2/4/pi^2/1e4;
disp([TMD.n, TMD.p])

%% high symmetry points
% select the MX2:
%  1 MoS2
%  2 MoSe2
%  3 WS2
%  4 WSe2

iType = 1;
Spin = -1;

ImportParameters;
CalculateSubmatrices;

Mesh.Nk = 201;
x = linspace(0,1,Mesh.Nk);
for ix = 1:Mesh.Nk
    K = [4*pi/3/TMD.a*x(ix), 0];
    H_MM = T.M + 2*T.MM(:,:,1)*cos(K*Parm.a1') + 2*T.MM(:,:,2)*cos(K*Parm.a2') + 2*T.MM(:,:,3)*cos(K*Parm.a3');
    H_XX = T.X + 2*T.XX(:,:,1)*cos(K*Parm.a1') + 2*T.XX(:,:,2)*cos(K*Parm.a2') + 2*T.XX(:,:,3)*cos(K*Parm.a3');
    H_MX = T.MX(:,:,1)*exp(-1i*K*Parm.d1.') + T.MX(:,:,2)*exp(-1i*K*Parm.d2.') + T.MX(:,:,3)*exp(-1i*K*Parm.d3.');
    H = [H_MM  H_MX; H_MX' H_XX];
    TMD.E_G2K(ix,:) = eig(H);
    if ix == 1
        [TMD.VG,TMD.EG] = eig(H);
    end;
    if ix == Mesh.Nk
        [TMD.VK,TMD.EK] = eig(H);
    end;
end;clear ix H_* K H


for ix = 1:Mesh.Nk
    K = [pi/TMD.a+pi/3/TMD.a*(1-x(ix)), pi/sqrt(3)/TMD.a*x(ix)];
    H_MM = T.M + 2*T.MM(:,:,1)*cos(K*Parm.a1') + 2*T.MM(:,:,2)*cos(K*Parm.a2') + 2*T.MM(:,:,3)*cos(K*Parm.a3');
    H_XX = T.X + 2*T.XX(:,:,1)*cos(K*Parm.a1') + 2*T.XX(:,:,2)*cos(K*Parm.a2') + 2*T.XX(:,:,3)*cos(K*Parm.a3');
    H_MX = T.MX(:,:,1)*exp(-1i*K*Parm.d1.') + T.MX(:,:,2)*exp(-1i*K*Parm.d2.') + T.MX(:,:,3)*exp(-1i*K*Parm.d3.');
    H = [H_MM  H_MX; H_MX' H_XX];
    TMD.E_K2M(ix,:) = eig(H);
end;clear ix H_* K H

for ix = 1:Mesh.Nk
    K = [pi/TMD.a*(1-x(ix)), pi/sqrt(3)/TMD.a*(1-x(ix))];
    H_MM = T.M + 2*T.MM(:,:,1)*cos(K*Parm.a1') + 2*T.MM(:,:,2)*cos(K*Parm.a2') + 2*T.MM(:,:,3)*cos(K*Parm.a3');
    H_XX = T.X + 2*T.XX(:,:,1)*cos(K*Parm.a1') + 2*T.XX(:,:,2)*cos(K*Parm.a2') + 2*T.XX(:,:,3)*cos(K*Parm.a3');
    H_MX = T.MX(:,:,1)*exp(-1i*K*Parm.d1.') + T.MX(:,:,2)*exp(-1i*K*Parm.d2.') + T.MX(:,:,3)*exp(-1i*K*Parm.d3.');
    H = [H_MM  H_MX; H_MX' H_XX];
    TMD.E_M2G(ix,:) = eig(H);
end;clear ix H_* K H

figure(iType)
plot(x,TMD.E_G2K/Q,'b',1+x/2,TMD.E_K2M/Q,'b',1.5+x*sqrt(3)/2,TMD.E_M2G/Q,'b','linewidth',3);hold on
set(gca,'fontsize',20);
plot(1+0*(-20:0.1:10),(-20:0.1:10),'k --','linewidth',2);
plot(1.5+0*(-20:0.1:10),(-20:0.1:10),'k --','linewidth',2);
xlim([0 2.366]); ylim([-13 3]); 
xticks([0 , 1 , 1.5 , 2.365]); xticklabels({'\Gamma','K','M','\Gamma'})
ylabel('E (eV)')
